package Models;

/**
 * Credits to this class
 *  http://stackoverflow.com/questions/156275/what-is-the-equivalent-of-the-c-pairl-r-in-java
 * @param <A>
 * @param <B>
 */
public class Tuple<A, B> {
	public A first;
	public B second;

	public Tuple(A first, B second) {
		super();
		this.first = first;
		this.second = second;
	}

	public int hashCode() {
		int hashFirst = first != null ? first.hashCode() : 0;
		int hashSecond = second != null ? second.hashCode() : 0;

		return (hashFirst + hashSecond) * hashSecond + hashFirst;
	}

	public boolean equals(Object other) {
		if (other instanceof Tuple) {
			Tuple otherPair = (Tuple) other;
			return ((this.first == otherPair.first || (this.first != null
					&& otherPair.first != null && this.first
						.equals(otherPair.first))) && (this.second == otherPair.second || (this.second != null
					&& otherPair.second != null && this.second
						.equals(otherPair.second))));
		}

		return false;
	}
	

	public String toString() {
		return "(" + first + ", " + second + ")";
	}

	

	public void setFirst(A first) {
		this.first = first;
	}


	public void setSecond(B second) {
		this.second = second;
	}
}
