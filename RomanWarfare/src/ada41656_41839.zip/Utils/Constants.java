package Utils;

public class Constants {
	public static int MAX_A = 4000;
	public static int MAX_P = 4000;
}
